package util;

import java.awt.Color;
import java.awt.Font;

/**
 * PURPOSE: Shared colors, fonts and sizes so every component matches the design.
 */
public final class UIConstants {

    private UIConstants() {}

    // Colors
    public static final Color RED = new Color(0xD9302A);        // active tab, Cancelled, sidebar indicator
    public static final Color GREEN = new Color(0x2E7D32);      // Completed label
    public static final Color GRAY_TEXT = new Color(0x777777);  // notes, quantity
    public static final Color BORDER = new Color(0x9A9A9A);     // card + field borders
    public static final Color PAGE_BG = new Color(0xD9D9D9);    // gray area around the white panel
    public static final Color SIDEBAR_BG = new Color(0xF7F7F7);
    public static final Color WHITE = Color.WHITE;
    public static final Color BLACK = Color.BLACK;

    // Fonts (Poppins if installed, otherwise Java falls back to a default font)
    public static final String FONT_FAMILY = "Poppins";
    public static final Font TITLE = new Font(FONT_FAMILY, Font.BOLD, 32);
    public static final Font BODY = new Font(FONT_FAMILY, Font.PLAIN, 14);
    public static final Font BODY_BOLD = new Font(FONT_FAMILY, Font.BOLD, 13);
    public static final Font SMALL = new Font(FONT_FAMILY, Font.PLAIN, 12);

    /**
     * Poppins (and some other fonts) may not contain the peso sign.
     * Use this for any label that shows money: it falls back to a font that has the glyph.
     */
    public static Font moneyFont(Font base) {
        if (base.canDisplay('₱')) return base;
        return new Font(Font.SANS_SERIF, base.getStyle(), base.getSize());
    }

    // Sizes
    public static final int SIDEBAR_WIDTH = 245;
    public static final int CARD_RADIUS = 12;
    public static final int IMAGE_WIDTH = 110;
    public static final int IMAGE_HEIGHT = 90;
}
