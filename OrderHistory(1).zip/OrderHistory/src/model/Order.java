package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * PURPOSE: Data holder for ONE finished order (this is what gets pushed onto the stack).
 * Getters only, because history should not be edited after it is stored.
 */
public class Order {

    private final String orderId;          // e.g. "D001", "T001"
    private final DiningOption diningOption;
    private final OrderStatus status;      // COMPLETED or CANCELLED
    private final List<OrderItem> items;
    private final LocalDateTime closedAt;

    public Order(String orderId, DiningOption diningOption, OrderStatus status, List<OrderItem> items) {
        this.orderId = orderId;
        this.diningOption = diningOption;
        this.status = status;
        this.items = Collections.unmodifiableList(new ArrayList<>(items));
        this.closedAt = LocalDateTime.now();
    }

    public String getOrderId() { return orderId; }
    public DiningOption getDiningOption() { return diningOption; }
    public OrderStatus getStatus() { return status; }
    public List<OrderItem> getItems() { return items; }
    public LocalDateTime getClosedAt() { return closedAt; }

    /** Number of item lines, shown as "Total items 2" in the design. */
    public int getItemCount() {
        return items.size();
    }

    /** Sum of every line's subtotal. */
    public double getTotalPrice() {
        double total = 0;
        for (OrderItem item : items) {
            total += item.getSubtotal();
        }
        return total;
    }
}
