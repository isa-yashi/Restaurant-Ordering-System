package model;

/**
 * PURPOSE: Data holder for one product line inside an Order.
 * (immutable: history must not change after it is stored)
 */
public class OrderItem {

    private final String name;
    private final String note;       // e.g. "Extra cheese", "No lettuce" (may be empty)
    private final String imagePath;  // may be null; the UI shows a placeholder then
    private final int quantity;      // shown as "3x"
    private final double unitPrice;

    public OrderItem(String name, String note, String imagePath, int quantity, double unitPrice) {
        this.name = name;
        this.note = note == null ? "" : note;
        this.imagePath = imagePath;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public String getName() { return name; }
    public String getNote() { return note; }
    public String getImagePath() { return imagePath; }
    public int getQuantity() { return quantity; }
    public double getUnitPrice() { return unitPrice; }

    /** quantity * unitPrice */
    public double getSubtotal() {
        return quantity * unitPrice;
    }
}
