import controller.OrderHistoryController;
import datastructure.OrderHistoryStack;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import model.DiningOption;
import model.Order;
import model.OrderItem;
import model.OrderStatus;
import ui.components.SidebarMenu;
import ui.pages.OrderHistoryPage;
import util.UIConstants;

/**
 * PURPOSE: Entry point. Creates the main window, adds SidebarMenu + OrderHistoryPage,
 * creates the OrderHistoryStack and OrderHistoryController, and pushes sample orders for testing.
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::start);
    }

    private static void start() {
        OrderHistoryStack stack = new OrderHistoryStack();
        OrderHistoryPage page = new OrderHistoryPage();
        OrderHistoryController controller = new OrderHistoryController(stack, page);

        addSampleOrders(controller);

        // gray area around the white page panel, like the design
        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(UIConstants.PAGE_BG);
        content.setBorder(BorderFactory.createEmptyBorder(20, 28, 20, 24));
        content.add(page, BorderLayout.CENTER);

        SidebarMenu sidebar = new SidebarMenu("Order History");

        JFrame frame = new JFrame("Order History");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(sidebar, BorderLayout.WEST);
        frame.add(content, BorderLayout.CENTER);
        frame.setMinimumSize(new Dimension(900, 600));
        frame.setSize(1100, 740);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /** Oldest first, so the LAST one pushed (T001) ends up on top of the stack. */
    private static void addSampleOrders(OrderHistoryController controller) {
        controller.addOrder(new Order("D001", DiningOption.DINE_IN, OrderStatus.COMPLETED, Arrays.asList(
                new OrderItem("Burgir burgir burgir burgir", "Extra cheese", "images/burger.png", 2, 50),
                new OrderItem("Burgir burgir burgir burgir", "No lettuce", "images/burger.png", 3, 50))));

        controller.addOrder(new Order("T001", DiningOption.TAKE_OUT, OrderStatus.CANCELLED, Arrays.asList(
                new OrderItem("Burgir burgir burgir burgir", "Extra cheese", "images/burger.png", 1, 50),
                new OrderItem("Burgir burgir burgir burgir", "No lettuce", "images/burger.png", 3, 50))));
    }
}
