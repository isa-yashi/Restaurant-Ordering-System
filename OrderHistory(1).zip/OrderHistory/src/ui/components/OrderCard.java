package ui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import model.Order;
import model.OrderItem;
import util.CurrencyFormatter;
import util.RoundedBorder;
import util.UIConstants;

/**
 * PURPOSE: One bordered card in the list = ONE order (e.g. "Order Id: D001").
 * Collapsed = only the first item is shown; "View More" expands to show every item.
 */
public class OrderCard extends JPanel {

    private final Order order;
    private final JPanel itemsPanel = new JPanel();
    private final JButton viewMoreButton = new JButton();
    private boolean expanded = false;

    public OrderCard(Order order) {
        this.order = order;

        setLayout(new BorderLayout(0, 8));
        setBackground(UIConstants.WHITE);
        setBorder(new RoundedBorder(UIConstants.CARD_RADIUS, UIConstants.BORDER, 12));

        add(buildHeader(), BorderLayout.NORTH);

        itemsPanel.setOpaque(false);
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        add(itemsPanel, BorderLayout.CENTER);

        add(buildFooter(), BorderLayout.SOUTH);

        rebuildItems();
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel id = new JLabel("Order Id: " + order.getOrderId());
        id.setFont(UIConstants.BODY);

        header.add(id, BorderLayout.WEST);
        header.add(new StatusLabel(order.getStatus()), BorderLayout.EAST);
        return header;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout(0, 4));
        footer.setOpaque(false);

        // "Total items N: P total", right aligned
        JLabel total = new JLabel("Total items " + order.getItemCount()
                + ": " + CurrencyFormatter.peso(order.getTotalPrice()));
        total.setFont(UIConstants.moneyFont(UIConstants.BODY_BOLD));
        JPanel totalRow = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 0));
        totalRow.setOpaque(false);
        totalRow.add(total);
        footer.add(totalRow, BorderLayout.NORTH);

        // "View More" toggle, centered (only when there is more than one item)
        if (order.getItems().size() > 1) {
            viewMoreButton.setFont(UIConstants.SMALL);
            viewMoreButton.setForeground(UIConstants.GRAY_TEXT);
            viewMoreButton.setBorderPainted(false);
            viewMoreButton.setContentAreaFilled(false);
            viewMoreButton.setFocusPainted(false);
            viewMoreButton.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
            viewMoreButton.setIconTextGap(8);
            viewMoreButton.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
            viewMoreButton.addActionListener(e -> toggleViewMore());
            updateViewMoreText();

            JPanel moreRow = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
            moreRow.setOpaque(false);
            moreRow.add(viewMoreButton);
            footer.add(moreRow, BorderLayout.SOUTH);
        }
        return footer;
    }

    private void toggleViewMore() {
        expanded = !expanded;
        rebuildItems();
        updateViewMoreText();
        revalidate();
        repaint();
    }

    private void updateViewMoreText() {
        viewMoreButton.setText(expanded ? "View Less" : "View More");
        viewMoreButton.setIcon(new ChevronIcon(expanded));
    }

    /** Small chevron drawn with lines (a font arrow can show as a box if the font lacks it). */
    private static class ChevronIcon implements javax.swing.Icon {
        private final boolean up;

        ChevronIcon(boolean up) { this.up = up; }

        public int getIconWidth() { return 14; }
        public int getIconHeight() { return 8; }

        public void paintIcon(java.awt.Component c, java.awt.Graphics g, int x, int y) {
            java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
            g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,
                    java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(UIConstants.GRAY_TEXT);
            g2.setStroke(new java.awt.BasicStroke(1.5f));
            int top = up ? y + 7 : y + 1;
            int tip = up ? y + 1 : y + 7;
            g2.drawLine(x + 1, top, x + 7, tip);
            g2.drawLine(x + 7, tip, x + 13, top);
            g2.dispose();
        }
    }

    private void rebuildItems() {
        itemsPanel.removeAll();
        List<OrderItem> items = order.getItems();
        int shown = expanded ? items.size() : Math.min(1, items.size());

        for (int i = 0; i < shown; i++) {
            if (i > 0) itemsPanel.add(Box.createVerticalStrut(14));
            itemsPanel.add(new OrderItemRow(items.get(i)));
        }
    }

    /** Lets the card keep its own height inside a BoxLayout list. */
    @Override
    public Dimension getMaximumSize() {
        return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
    }
}
