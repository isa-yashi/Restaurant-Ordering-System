package controller;

import datastructure.OrderHistoryStack;
import java.util.List;
import model.DiningOption;
import model.Order;
import model.OrderStatus;
import ui.pages.OrderHistoryPage;

/**
 * PURPOSE: Connects the UI to the stack. The page never touches the stack directly.
 * Keeps the three active filters (status, dining option, search text) and combines them (AND).
 */
public class OrderHistoryController {

    private final OrderHistoryStack stack;
    private final OrderHistoryPage page;

    private OrderStatus currentStatus = null;     // null = All
    private DiningOption currentDining = null;    // null = All
    private String searchText = "";

    public OrderHistoryController(OrderHistoryStack stack, OrderHistoryPage page) {
        this.stack = stack;
        this.page = page;

        page.setOnStatusSelected(this::onStatusSelected);
        page.setOnDiningSelected(this::onDiningSelected);
        page.setOnSearch(this::onSearch);

        applyFilters();
    }

    /** Called when an order is completed or cancelled: push it, then redraw. */
    public void addOrder(Order order) {
        stack.push(order);
        applyFilters();
    }

    public void onStatusSelected(OrderStatus status) {
        this.currentStatus = status;
        applyFilters();
    }

    public void onDiningSelected(DiningOption dining) {
        this.currentDining = dining;
        applyFilters();
    }

    public void onSearch(String text) {
        this.searchText = text == null ? "" : text;
        applyFilters();
    }

    private void applyFilters() {
        List<Order> visible = stack.filter(currentStatus, currentDining, searchText);
        page.refresh(visible);
    }
}
