package ui.components;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import util.UIConstants;

/**
 * PURPOSE: Left navigation panel shared by all pages (logo + menu buttons).
 * A red bar marks the currently selected page. Reuse it on every page.
 */
public class SidebarMenu extends JPanel {

    public static final String[] PAGES = {
            "Menu & Ordering", "Current Order", "Order Queue", "Order History", "Inventory"
    };

    private Consumer<String> onNavigate = p -> { };

    public SidebarMenu(String activePage) {
        setBackground(UIConstants.SIDEBAR_BG);
        setPreferredSize(new Dimension(UIConstants.SIDEBAR_WIDTH, 0));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));

        add(buildLogo());
        add(Box.createVerticalStrut(45));

        for (String page : PAGES) {
            MenuItem item = new MenuItem(page, page.equals(activePage));
            item.addActionListener(e -> onNavigate.accept(page));
            add(item);
            add(Box.createVerticalStrut(18));
        }
        add(Box.createVerticalGlue());
    }

    public void setOnNavigate(Consumer<String> callback) {
        this.onNavigate = callback;
    }

    private JPanel buildLogo() {
        JPanel logo = new JPanel(new BorderLayout(14, 0));
        logo.setOpaque(false);
        logo.setBorder(BorderFactory.createEmptyBorder(0, 18, 0, 10));
        logo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        logo.setAlignmentX(LEFT_ALIGNMENT);   // same alignment as the menu buttons, or the layout shifts

        JLabel circle = new JLabel("R", SwingConstants.CENTER);   // placeholder for the real logo image
        circle.setOpaque(true);
        circle.setBackground(java.awt.Color.WHITE);
        circle.setFont(UIConstants.TITLE.deriveFont(22f));
        circle.setPreferredSize(new Dimension(56, 56));
        circle.setBorder(BorderFactory.createLineBorder(UIConstants.BORDER));

        JLabel name = new JLabel("<html>LOREM<br>IPSUM</html>");
        name.setFont(UIConstants.TITLE.deriveFont(24f));

        logo.add(circle, BorderLayout.WEST);
        logo.add(name, BorderLayout.CENTER);
        return logo;
    }

    /** Flat menu button; draws a red indicator bar on the right edge when active. */
    private static class MenuItem extends JButton {

        private final boolean active;

        MenuItem(String text, boolean active) {
            super(text);
            this.active = active;
            setFont(UIConstants.SMALL.deriveFont(14f));
            setHorizontalAlignment(SwingConstants.LEFT);
            setBorder(BorderFactory.createEmptyBorder(0, 60, 0, 0));   // space for a future icon
            setContentAreaFilled(false);
            setFocusPainted(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setAlignmentX(LEFT_ALIGNMENT);
            Dimension size = new Dimension(UIConstants.SIDEBAR_WIDTH, 46);
            setPreferredSize(size);
            setMaximumSize(size);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (active) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UIConstants.RED);
                g2.fillRoundRect(getWidth() - 10, 0, 14, getHeight(), 10, 10);
                g2.dispose();
            }
        }
    }
}
