# Order History (Java Swing)

Order History page for the restaurant system. Orders are stored in a **stack** (newest on top).

## Run

```
cd OrderHistory
mkdir out
javac -encoding UTF-8 -d out $(find src -name "*.java")     # Windows: dir /s /b src\*.java > files.txt, then javac -d out @files.txt
java -cp out Main
```

## Folders

| Folder | Purpose |
|---|---|
| `src/ui/pages` | Full screens (OrderHistoryPage) |
| `src/ui/components` | Reusable UI parts (OrderCard, OrderItemRow, FilterTabs, DiningOptionDropdown, SearchBar, SidebarMenu, StatusLabel) |
| `src/model` | Data classes (Order, OrderItem, OrderStatus, DiningOption) |
| `src/datastructure` | OrderHistoryStack, the stack that stores the orders |
| `src/controller` | OrderHistoryController, which connects the UI to the stack and applies filters |
| `src/util` | UIConstants, CurrencyFormatter, RoundedBorder |

## Notes

- To record a real order: `controller.addOrder(new Order(...))`. This pushes it onto the stack and redraws the list.
- Item pictures: put the image file at the path given in `OrderItem` (the samples use `images/burger.png`). If the file is missing, a "No image" box is shown.
- The Poppins font is used when installed; otherwise Java uses a default font.
