package datastructure;

import java.util.ArrayList;
import java.util.List;
import model.DiningOption;
import model.Order;
import model.OrderItem;
import model.OrderStatus;

/**
 * PURPOSE: The STACK (LIFO) that stores every order taken. This is the core logic of the page.
 * The most recent order sits on top, so it appears FIRST in the Order History list.
 *
 * Implemented manually with linked nodes (no java.util.Stack).
 * Reading methods (toList, filter) walk from top to bottom and never change the stack.
 */
public class OrderHistoryStack {

    private static class Node {
        final Order data;
        Node next;

        Node(Order data, Node next) {
            this.data = data;
            this.next = next;
        }
    }

    private Node top;
    private int size;

    /** Put a new finished order on top. */
    public void push(Order order) {
        top = new Node(order, top);
        size++;
    }

    /** Remove and return the newest order, or null if empty. */
    public Order pop() {
        if (top == null) return null;
        Order order = top.data;
        top = top.next;
        size--;
        return order;
    }

    /** Look at the newest order without removing it, or null if empty. */
    public Order peek() {
        return top == null ? null : top.data;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public int size() {
        return size;
    }

    /** All orders from newest (top) to oldest (bottom). The stack is left untouched. */
    public List<Order> toList() {
        return filter(null, null, "");
    }

    /**
     * Walks the stack top to bottom and returns the orders that match ALL given filters.
     *
     * @param status     null = all statuses
     * @param dining     null = all dining options
     * @param searchText matches the order ID or any item name (case-insensitive); blank = no search
     */
    public List<Order> filter(OrderStatus status, DiningOption dining, String searchText) {
        List<Order> result = new ArrayList<>();
        String query = searchText == null ? "" : searchText.trim().toLowerCase();

        for (Node n = top; n != null; n = n.next) {
            Order o = n.data;
            if (status != null && o.getStatus() != status) continue;
            if (dining != null && o.getDiningOption() != dining) continue;
            if (!query.isEmpty() && !matches(o, query)) continue;
            result.add(o);
        }
        return result;
    }

    private boolean matches(Order order, String query) {
        if (order.getOrderId().toLowerCase().contains(query)) return true;
        for (OrderItem item : order.getItems()) {
            if (item.getName().toLowerCase().contains(query)) return true;
        }
        return false;
    }
}
