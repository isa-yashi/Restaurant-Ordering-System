package model;

/**
 * PURPOSE: The possible end states of an order, used by the status filter tabs
 * and by StatusLabel.
 */
public enum OrderStatus {
    COMPLETED("Completed"),
    CANCELLED("Cancelled");

    private final String label;

    OrderStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
