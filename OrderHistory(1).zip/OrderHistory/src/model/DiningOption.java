package model;

/**
 * PURPOSE: How the customer received the order. Used by the "Dining option" dropdown
 * and for the order ID prefix (D = dine in, T = take out, L = delivery).
 *
 * "All" in the dropdown is not a value here; the controller treats null as "no filter".
 */
public enum DiningOption {
    DINE_IN("Dine in", 'D'),
    TAKE_OUT("Take out", 'T'),
    DELIVERY("Delivery", 'L');

    private final String label;
    private final char prefix;

    DiningOption(String label, char prefix) {
        this.label = label;
        this.prefix = prefix;
    }

    public String getLabel() {
        return label;
    }

    public char getPrefix() {
        return prefix;
    }
}
