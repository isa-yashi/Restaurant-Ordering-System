package ui.components;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import model.OrderStatus;
import util.UIConstants;

/**
 * PURPOSE: The pill buttons "All | Completed | Cancelled" that filter by order STATUS.
 * Active tab = red filled pill with white text; inactive = white pill with black outline.
 * The callback receives null for "All".
 */
public class FilterTabs extends JPanel {

    private final List<PillButton> buttons = new ArrayList<>();
    private Consumer<OrderStatus> onSelect = s -> { };

    public FilterTabs() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 8, 0));
        setOpaque(false);

        addTab("All", null);
        addTab("Completed", OrderStatus.COMPLETED);
        addTab("Cancelled", OrderStatus.CANCELLED);

        select(0);
    }

    public void setOnSelect(Consumer<OrderStatus> callback) {
        this.onSelect = callback;
    }

    private void addTab(String text, OrderStatus status) {
        PillButton button = new PillButton(text);
        button.addActionListener(e -> {
            select(buttons.indexOf(button));
            onSelect.accept(status);
        });
        buttons.add(button);
        add(button);
    }

    private void select(int index) {
        for (int i = 0; i < buttons.size(); i++) {
            buttons.get(i).setActive(i == index);
        }
    }

    /** Rounded pill-shaped button that can be active (red) or inactive (outlined). */
    private static class PillButton extends JButton {

        private boolean active;

        PillButton(String text) {
            super(text);
            setFont(UIConstants.BODY_BOLD);
            setBorder(BorderFactory.createEmptyBorder(4, 18, 4, 18));
            setContentAreaFilled(false);
            setFocusPainted(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        void setActive(boolean active) {
            this.active = active;
            setForeground(active ? Color.WHITE : Color.BLACK);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int arc = getHeight();
            if (active) {
                g2.setColor(UIConstants.RED);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            } else {
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
                g2.setColor(Color.BLACK);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            }
            g2.dispose();
            super.paintComponent(g);   // draws the text on top
        }
    }
}
