package ui.components;

import java.awt.Component;
import java.awt.Dimension;
import java.util.function.Consumer;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JPanel;
import model.DiningOption;
import util.RoundedBorder;
import util.UIConstants;

/**
 * PURPOSE: The "Dining option" dropdown (All / Dine in / Take out / Delivery).
 * Works together with FilterTabs: both filters apply at the same time.
 * The callback receives null for "All".
 */
public class DiningOptionDropdown extends JPanel {

    private static final String ALL = "All";

    private final JComboBox<String> combo = new JComboBox<>();
    private Consumer<DiningOption> onSelect = d -> { };

    public DiningOptionDropdown() {
        setOpaque(false);
        setLayout(new java.awt.BorderLayout());

        combo.addItem(ALL);
        for (DiningOption option : DiningOption.values()) {
            combo.addItem(option.getLabel());
        }

        combo.setFont(UIConstants.SMALL);
        combo.setBackground(UIConstants.WHITE);
        combo.setBorder(new RoundedBorder(8, UIConstants.BORDER, 2));
        combo.setPreferredSize(new Dimension(190, 32));

        // the closed box shows "Dining option: <choice>", the open list shows just the choices
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                String text = index == -1 ? "Dining option: " + value : String.valueOf(value);
                return super.getListCellRendererComponent(list, text, index, isSelected, cellHasFocus);
            }
        });

        combo.addActionListener(e -> onSelect.accept(selectedOption()));
        add(combo, java.awt.BorderLayout.CENTER);
    }

    public void setOnSelect(Consumer<DiningOption> callback) {
        this.onSelect = callback;
    }

    private DiningOption selectedOption() {
        int index = combo.getSelectedIndex();
        return index <= 0 ? null : DiningOption.values()[index - 1];
    }
}
