package ui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.BasicStroke;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import util.RoundedBorder;
import util.UIConstants;

/**
 * PURPOSE: Rounded search field with magnifier icon (top right of the page).
 * Sends the typed text to the callback on every change. Matches Order ID or item name.
 */
public class SearchBar extends JPanel {

    private static final String PLACEHOLDER = "Search";

    private final JTextField field = new JTextField() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText().isEmpty()) {          // draw the "Search" hint
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                        RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(UIConstants.GRAY_TEXT);
                g2.setFont(getFont());
                g2.drawString(PLACEHOLDER, getInsets().left,
                        (getHeight() + g2.getFontMetrics().getAscent()
                                - g2.getFontMetrics().getDescent()) / 2);
                g2.dispose();
            }
        }
    };

    private Consumer<String> onSearch = s -> { };

    public SearchBar() {
        setLayout(new BorderLayout(8, 0));
        setBackground(UIConstants.WHITE);
        setBorder(new RoundedBorder(32, UIConstants.BLACK, 3));
        setPreferredSize(new Dimension(350, 34));

        field.setBorder(BorderFactory.createEmptyBorder());
        field.setFont(UIConstants.SMALL);
        field.setOpaque(false);

        add(new MagnifierIcon(), BorderLayout.WEST);
        add(field, BorderLayout.CENTER);

        field.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { fire(); }
            public void removeUpdate(DocumentEvent e) { fire(); }
            public void changedUpdate(DocumentEvent e) { fire(); }
        });
    }

    public void setOnSearch(Consumer<String> callback) {
        this.onSearch = callback;
    }

    private void fire() {
        onSearch.accept(field.getText());
    }

    /** Simple magnifier drawn with shapes, so no image file is needed. */
    private static class MagnifierIcon extends JComponent {
        MagnifierIcon() {
            setPreferredSize(new Dimension(22, 22));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2f));
            g2.drawOval(2, 2, 13, 13);
            g2.drawLine(13, 13, 20, 20);
            g2.dispose();
        }
    }
}
