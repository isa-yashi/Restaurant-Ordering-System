package ui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import model.OrderItem;
import util.CurrencyFormatter;
import util.UIConstants;

/**
 * PURPOSE: One item line inside an OrderCard
 * (image on the left, name + note in the middle, quantity + price on the right).
 */
public class OrderItemRow extends JPanel {

    public OrderItemRow(OrderItem item) {
        setLayout(new BorderLayout(14, 0));
        setOpaque(false);

        add(buildImage(item.getImagePath()), BorderLayout.WEST);
        add(buildDetails(item), BorderLayout.CENTER);
        add(buildPrice(item), BorderLayout.EAST);
    }

    private JLabel buildImage(String path) {
        JLabel label = new JLabel();
        Dimension size = new Dimension(UIConstants.IMAGE_WIDTH, UIConstants.IMAGE_HEIGHT);
        label.setPreferredSize(size);
        label.setMinimumSize(size);
        label.setHorizontalAlignment(SwingConstants.CENTER);

        if (path != null && new File(path).exists()) {
            Image scaled = new ImageIcon(path).getImage()
                    .getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
            label.setIcon(new ImageIcon(scaled));
        } else {
            // placeholder when there is no picture
            label.setText("No image");
            label.setFont(UIConstants.SMALL);
            label.setForeground(UIConstants.GRAY_TEXT);
            label.setBorder(BorderFactory.createLineBorder(UIConstants.BORDER));
        }
        return label;
    }

    private JPanel buildDetails(OrderItem item) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel name = new JLabel(item.getName());
        name.setFont(UIConstants.BODY);

        JLabel note = new JLabel(item.getNote());
        note.setFont(UIConstants.SMALL);
        note.setForeground(UIConstants.GRAY_TEXT);

        panel.add(Box_vstrut(6));
        panel.add(name);
        panel.add(note);
        return panel;
    }

    private JPanel buildPrice(OrderItem item) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel qty = new JLabel(item.getQuantity() + "x");
        qty.setFont(UIConstants.SMALL);
        qty.setForeground(UIConstants.GRAY_TEXT);
        qty.setAlignmentX(RIGHT_ALIGNMENT);

        JLabel price = new JLabel(CurrencyFormatter.peso(item.getUnitPrice()));
        price.setFont(UIConstants.moneyFont(UIConstants.SMALL));
        price.setAlignmentX(RIGHT_ALIGNMENT);

        panel.add(javax.swing.Box.createVerticalGlue());
        panel.add(qty);
        panel.add(price);
        return panel;
    }

    private static java.awt.Component Box_vstrut(int h) {
        return javax.swing.Box.createVerticalStrut(h);
    }
}
