package ui.components;

import javax.swing.JLabel;
import model.OrderStatus;
import util.UIConstants;

/**
 * PURPOSE: Small colored status text shown at the top right of an OrderCard
 * (red bold "Cancelled", green bold "Completed").
 */
public class StatusLabel extends JLabel {

    public StatusLabel(OrderStatus status) {
        super(status.getLabel());
        setFont(UIConstants.BODY_BOLD);
        setForeground(status == OrderStatus.CANCELLED ? UIConstants.RED : UIConstants.GREEN);
    }
}
