package util;

/**
 * PURPOSE: One place to format money the same way everywhere (peso sign, 2 decimals),
 * e.g. 250 -> "₱ 250.00". Used by OrderCard and OrderItemRow.
 */
public final class CurrencyFormatter {

    private CurrencyFormatter() {}

    public static String peso(double amount) {
        return String.format("₱ %,.2f", amount);
    }
}
