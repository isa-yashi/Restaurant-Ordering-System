package ui.pages;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import model.DiningOption;
import model.Order;
import model.OrderStatus;
import ui.components.DiningOptionDropdown;
import ui.components.FilterTabs;
import ui.components.OrderCard;
import ui.components.SearchBar;
import util.UIConstants;

/**
 * PURPOSE: The main "Order History" screen (the white panel on the right of the mockup).
 * It only DISPLAYS what the controller gives it through refresh(); it does not filter by itself.
 * The sidebar is added by the main window, not by this page.
 */
public class OrderHistoryPage extends JPanel {

    private final SearchBar searchBar = new SearchBar();
    private final FilterTabs filterTabs = new FilterTabs();
    private final DiningOptionDropdown diningDropdown = new DiningOptionDropdown();
    private final ListPanel listPanel = new ListPanel();
    private final JScrollPane scrollPane = new JScrollPane(listPanel);

    public OrderHistoryPage() {
        setLayout(new BorderLayout(0, 12));
        setBackground(UIConstants.WHITE);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        add(buildTop(), BorderLayout.NORTH);

        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(UIConstants.WHITE);

        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(UIConstants.WHITE);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel buildTop() {
        JLabel title = new JLabel("Order History");
        title.setFont(UIConstants.TITLE);

        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setOpaque(false);
        titleRow.add(title, BorderLayout.WEST);
        titleRow.add(wrapCentered(searchBar), BorderLayout.EAST);

        JPanel filterRow = new JPanel(new BorderLayout());
        filterRow.setOpaque(false);
        filterRow.add(filterTabs, BorderLayout.WEST);
        filterRow.add(diningDropdown, BorderLayout.EAST);

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.add(titleRow);
        top.add(Box.createVerticalStrut(8));
        top.add(filterRow);
        return top;
    }

    private JPanel wrapCentered(java.awt.Component c) {
        JPanel p = new JPanel(new java.awt.GridBagLayout());
        p.setOpaque(false);
        p.add(c);
        return p;
    }

    // ---- hooks used by the controller -------------------------------------------------

    public void setOnSearch(Consumer<String> callback) {
        searchBar.setOnSearch(callback);
    }

    public void setOnStatusSelected(Consumer<OrderStatus> callback) {
        filterTabs.setOnSelect(callback);
    }

    public void setOnDiningSelected(Consumer<DiningOption> callback) {
        diningDropdown.setOnSelect(callback);
    }

    /** Clears the list and redraws one OrderCard per order (list order = stack order, newest first). */
    public void refresh(List<Order> orders) {
        listPanel.removeAll();

        if (orders.isEmpty()) {
            JLabel empty = new JLabel("No orders found.", SwingConstants.CENTER);
            empty.setFont(UIConstants.BODY);
            empty.setForeground(UIConstants.GRAY_TEXT);
            empty.setAlignmentX(CENTER_ALIGNMENT);
            listPanel.add(Box.createVerticalStrut(40));
            listPanel.add(empty);
        } else {
            for (Order order : orders) {
                listPanel.add(new OrderCard(order));
                listPanel.add(Box.createVerticalStrut(14));
            }
        }

        listPanel.revalidate();
        listPanel.repaint();
        SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(0));
    }

    /** Panel that follows the viewport width so cards stretch instead of showing a side scrollbar. */
    private static class ListPanel extends JPanel implements Scrollable {
        public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 16; }
        public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return r.height; }
        public boolean getScrollableTracksViewportWidth() { return true; }
        public boolean getScrollableTracksViewportHeight() { return false; }
    }
}
